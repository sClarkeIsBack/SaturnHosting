import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnNhdHVybmhvc3Rpbmc=')

name = b.b64decode('U2F0dXJuIEhvc3Rpbmc=')

host = b.b64decode('aHR0cDovL2VjbGlwc2UtaXB0di5kZG5zLm5ldA==')

port = b.b64decode('MjU0NjE=')