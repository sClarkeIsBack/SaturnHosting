import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnNhdHVybmhvc3Rpbmc=')

name = b.b64decode('U2F0dXJuIEhvc3Rpbmc=')

host = b.b64decode('aHR0cDovL3NhdHVybmhvc3RpbmcuZGRucy5uZXQ=')

port = b.b64decode('MjU0NjE=')